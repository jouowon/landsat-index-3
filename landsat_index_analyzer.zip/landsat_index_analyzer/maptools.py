# -*- coding: utf-8 -*-
"""지도 도구: 시·군 선택(마우스를 올리면 이름 표시) · 폴리곤/사각형 그리기"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QToolTip
from qgis.core import QgsGeometry, QgsPointXY, QgsRectangle, QgsWkbTypes
from qgis.gui import QgsMapTool, QgsRubberBand

try:                                   # QGIS 3.30+
    from qgis.core import Qgis
    POLYGON = Qgis.GeometryType.Polygon
except (ImportError, AttributeError):
    POLYGON = QgsWkbTypes.PolygonGeometry

LEFT = Qt.MouseButton.LeftButton
RIGHT = Qt.MouseButton.RightButton


class RegionTool(QgsMapTool):
    """클릭하면 시·군 선택/해제, 마우스를 올리면 시·군 이름 툴팁"""

    def __init__(self, canvas, finder, on_click):
        super().__init__(canvas)
        self.finder = finder            # 지도 좌표 → (key, feature) 또는 None
        self.on_click = on_click
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._last = None

    def canvasMoveEvent(self, e):
        hit = self.finder(self.toMapCoordinates(e.pos()))
        name = hit[0] if hit else None
        if name:
            QToolTip.showText(self.canvas().mapToGlobal(e.pos()), name, self.canvas())
        elif self._last:
            QToolTip.hideText()
        self._last = name

    def canvasReleaseEvent(self, e):
        if e.button() != LEFT:
            return
        hit = self.finder(self.toMapCoordinates(e.pos()))
        if hit:
            self.on_click(hit[1])

    def deactivate(self):
        QToolTip.hideText()
        super().deactivate()


class DrawTool(QgsMapTool):
    """폴리곤: 왼쪽 클릭으로 점 추가, 오른쪽 클릭(또는 더블클릭)으로 완료 / 사각형: 드래그"""

    def __init__(self, canvas, rect, on_done):
        super().__init__(canvas)
        self.rect = rect
        self.on_done = on_done
        self.rb = QgsRubberBand(canvas, POLYGON)
        self.rb.setColor(QColor(31, 95, 191, 40))
        self.rb.setStrokeColor(QColor(31, 95, 191))
        self.rb.setWidth(2)
        self.pts = []
        self.start = None
        self.setCursor(Qt.CursorShape.CrossCursor)

    def _show(self, pts):
        self.rb.reset(POLYGON)
        for i, p in enumerate(pts):
            self.rb.addPoint(p, i == len(pts) - 1)

    def canvasPressEvent(self, e):
        if self.rect and e.button() == LEFT:
            self.start = self.toMapCoordinates(e.pos())

    def canvasMoveEvent(self, e):
        p = self.toMapCoordinates(e.pos())
        if self.rect:
            if self.start:
                r = QgsRectangle(self.start, p)
                self._show([QgsPointXY(r.xMinimum(), r.yMinimum()), QgsPointXY(r.xMaximum(), r.yMinimum()),
                            QgsPointXY(r.xMaximum(), r.yMaximum()), QgsPointXY(r.xMinimum(), r.yMaximum())])
        elif self.pts:
            self._show(self.pts + [p])

    def canvasReleaseEvent(self, e):
        p = self.toMapCoordinates(e.pos())
        if self.rect:
            if e.button() == LEFT and self.start:
                r = QgsRectangle(self.start, p)
                self.start = None
                self.rb.reset(POLYGON)
                if r.width() > 0 and r.height() > 0:
                    self.on_done(QgsGeometry.fromRect(r))
            return
        if e.button() == LEFT:
            self.pts.append(p)
            self._show(self.pts)
        elif e.button() == RIGHT:
            self._finish()

    def canvasDoubleClickEvent(self, e):
        if not self.rect:
            self._finish()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.pts = []
            self.start = None
            self.rb.reset(POLYGON)
        elif e.key() in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete) and self.pts:
            self.pts.pop()
            self._show(self.pts)

    def _finish(self):
        # 더블클릭은 같은 점이 두 번 들어오므로 중복 제거
        pts = [p for i, p in enumerate(self.pts) if i == 0 or p != self.pts[i - 1]]
        self.pts = []
        self.rb.reset(POLYGON)
        if len(pts) >= 3:
            self.on_done(QgsGeometry.fromPolygonXY([pts + [pts[0]]]))

    def deactivate(self):
        self.pts = []
        self.start = None
        self.rb.reset(POLYGON)
        super().deactivate()
