# -*- coding: utf-8 -*-


def classFactory(iface):
    from .plugin import LandsatIndexPlugin
    return LandsatIndexPlugin(iface)
