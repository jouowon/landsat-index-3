# -*- coding: utf-8 -*-
"""
Landsat 지수 분석 패널
  [1~4 분석] 폴더 → 지수 → 영상 불러오기 → 분석 실행
  [5 분류]   임계값 조정 · 확정
  [6 통계]   행정구역(시·군) 선택 통계 · 직접 그린 영역 통계
"""
import csv
import math
import os
import tempfile

from qgis.PyQt.QtCore import Qt, QTimer, QRectF
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QStandardItemModel
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDockWidget, QDoubleSpinBox, QFileDialog,
    QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QProgressBar,
    QPushButton, QScrollArea, QSlider, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsColorRampShader, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsFillSymbol, QgsPalLayerSettings, QgsPointXY, QgsProject, QgsRasterLayer, QgsRasterShader,
    QgsRectangle, QgsRuleBasedRenderer, QgsSingleBandPseudoColorRenderer, QgsSpatialIndex,
    QgsTextBufferSettings, QgsTextFormat, QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

from . import core
from .core import BAND_INFO, CLASS_COLOR, HIST_BINS, INDICES, dir_sym, ramp_color
from .maptools import DrawTool, RegionTool

PLUGIN_DIR = os.path.dirname(__file__)
GROUP_NAME = 'Landsat 지수 분석'
ADMIN_NAME = '행정구역 (시·군)'
DRAW_NAME = '직접 그린 영역'
ESRI_STREET = ('type=xyz&url=https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/'
               'MapServer/tile/%7Bz%7D/%7By%7D/%7Bx%7D&zmax=19&zmin=0')

try:                                   # QGIS 3.30+
    from qgis.core import Qgis
    RAMP_LINEAR = Qgis.ShaderInterpolationMethod.Linear
    RAMP_DISCRETE = Qgis.ShaderInterpolationMethod.Discrete
except (ImportError, AttributeError):
    RAMP_LINEAR = QgsColorRampShader.Interpolated
    RAMP_DISCRETE = QgsColorRampShader.Discrete
try:
    from qgis.core import Qgis
    OVER_POINT = Qgis.LabelPlacement.OverPoint
except (ImportError, AttributeError):
    OVER_POINT = QgsPalLayerSettings.OverPoint

try:
    from qgis.PyQt.QtCore import QMetaType
    INT_TYPE = QMetaType.Type.Int
except (ImportError, AttributeError):
    from qgis.PyQt.QtCore import QVariant
    INT_TYPE = QVariant.Int


def fmt(v, d=2):
    return '–' if v is None or (isinstance(v, float) and math.isnan(v)) else f'{v:,.{d}f}'


def fmt_area(m2):
    return f'{m2 / 1e6:,.3f} km² ({m2 / 1e4:,.1f} ha)'


def pct_of(a, b):
    return '–' if a is None or not b else f'{100 * a / b:,.1f}'


def align_right(it):
    a = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
    try:
        it.setTextAlignment(a)
    except TypeError:              # PyQt5 는 int 를 받음
        it.setTextAlignment(int(a))


class HistWidget(QWidget):
    """지수 분포 히스토그램 (임계값 통과 구간은 색, 나머지는 회색)"""

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(100)
        self.r = None

    def set_result(self, r):
        self.r = r
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor(255, 255, 255))
        r = self.r
        if r is None:
            p.setPen(QColor(138, 148, 163))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, '분석 후 지수 분포가 표시됩니다')
            return
        pad, bw = 14, w / HIST_BINS
        mx = max(int(r.hist.max()), 1)
        cls = QColor(*CLASS_COLOR[r.key]) if r.is_class_view() else None
        for i in range(HIST_BINS):
            v = -1 + (i + 0.5) * 2 / HIST_BINS
            if not r.passes(v):
                col = QColor(207, 214, 223)
            else:
                col = cls or QColor(*ramp_color((v - r.vmin) / (r.vmax - r.vmin)))
            bh = math.sqrt(r.hist[i] / mx) * (h - pad - 4)
            p.fillRect(QRectF(i * bw, h - pad - bh, max(1.0, bw - 0.3), bh), col)
        tx = (r.thr + 1) / 2 * w
        p.fillRect(QRectF(tx - 1, 2, 2, h - pad - 2), QColor(17, 17, 17))
        p.setPen(QColor(107, 118, 134))
        f = p.font()
        f.setPointSize(7)
        p.setFont(f)
        p.drawText(QRectF(2, h - pad, 40, pad), Qt.AlignmentFlag.AlignLeft, '-1')
        p.drawText(QRectF(w / 2 - 20, h - pad, 40, pad), Qt.AlignmentFlag.AlignHCenter, '0')
        p.drawText(QRectF(w - 42, h - pad, 40, pad), Qt.AlignmentFlag.AlignRight, '1')


class AnalyzerDock(QDockWidget):
    def __init__(self, iface):
        super().__init__('Landsat 지수 분석')
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.project = QgsProject.instance()
        self.scenes = {}
        self.scene = None
        self.grid = None
        self.results = {}           # key → core.Result
        self.active = None
        self.band_layers = {}       # 밴드 번호 → 레이어 id
        self.admin_id = None
        self.admin_index = None
        self.admin_geoms = {}       # fid → (key, geometry, area_km2)
        self.admin_sel = {}         # key → fid (선택 순서 유지)
        self.admin_rows = []
        self.draw_rows = []
        self.draw_id = None
        self.poly_count = 0
        self.outdir = tempfile.mkdtemp(prefix='landsat_index_')
        self.region_tool = RegionTool(self.canvas, self.region_at, self.toggle_region)
        self.draw_tool = None
        self.render_timer = QTimer(self)
        self.render_timer.setSingleShot(True)
        self.render_timer.setInterval(120)
        self.render_timer.timeout.connect(self.render_active)

        self._build_ui()
        self.canvas.mapToolSet.connect(self._on_tool_changed)
        self.update_ui()

    # ─────────────────────────── UI ───────────────────────────
    def _build_ui(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self._scroll(self._tab_run()), '1~4 분석')
        self.tabs.addTab(self._scroll(self._tab_cls()), '5 분류')
        self.tabs.addTab(self._scroll(self._tab_stat()), '6 통계')
        self.setWidget(self.tabs)

    @staticmethod
    def _scroll(w):
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setWidget(w)
        return sa

    @staticmethod
    def _group(title):
        g = QGroupBox(title)
        lay = QVBoxLayout(g)
        return g, lay

    @staticmethod
    def _label(text='', muted=False):
        lb = QLabel(text)
        lb.setWordWrap(True)
        if muted:
            lb.setStyleSheet('color:#6b7686;')
        return lb

    def _tab_run(self):
        w = QWidget()
        v = QVBoxLayout(w)

        g, lay = self._group('1. 영상 폴더 선택')
        row = QHBoxLayout()
        self.folder_edit = QLineEdit()
        self.folder_edit.setReadOnly(True)
        self.folder_edit.setPlaceholderText('Landsat 장면 폴더 (.TIF 또는 USGS .tar)')
        btn = QPushButton('📁 폴더 선택')
        btn.clicked.connect(self.choose_folder)
        row.addWidget(self.folder_edit)
        row.addWidget(btn)
        lay.addLayout(row)
        self.scene_combo = QComboBox()
        self.scene_combo.currentIndexChanged.connect(self.select_scene)
        lay.addWidget(self.scene_combo)
        self.scene_info = self._label('영상 미선택', muted=True)
        lay.addWidget(self.scene_info)
        v.addWidget(g)

        g, lay = self._group('2. 다중분광지수 선택')
        self.index_combo = QComboBox()
        for k, d in INDICES.items():
            self.index_combo.addItem(f'{k} · {d["name"]} (B{d["bands"][0]}, B{d["bands"][1]})', k)
        self.index_combo.currentIndexChanged.connect(self.on_index_changed)
        lay.addWidget(self.index_combo)
        self.formula = self._label('', muted=True)
        lay.addWidget(self.formula)
        v.addWidget(g)

        g, lay = self._group('3. 영상 불러오기')
        self.need_label = self._label()
        lay.addWidget(self.need_label)
        row = QHBoxLayout()
        row.addWidget(QLabel('분석 해상도'))
        self.res_combo = QComboBox()
        for r, t in ((30, '30 m (원본)'), (60, '60 m'), (90, '90 m'), (150, '150 m (빠름)')):
            self.res_combo.addItem(t, r)
        self.res_combo.setCurrentIndex(1)
        row.addWidget(self.res_combo, 1)
        lay.addLayout(row)
        self.cloud_chk = QCheckBox('구름·그림자 마스킹 (QA_PIXEL)')
        self.cloud_chk.setChecked(True)
        lay.addWidget(self.cloud_chk)
        self.btn_load = QPushButton('영상 불러오기')
        self.btn_load.clicked.connect(self.load_images)
        lay.addWidget(self.btn_load)
        self.load_info = self._label('', muted=True)
        lay.addWidget(self.load_info)
        v.addWidget(g)

        g, lay = self._group('4. 분석 실행')
        self.btn_run = QPushButton('▶ 분석 실행')
        self.btn_run.clicked.connect(self.run_analysis)
        lay.addWidget(self.btn_run)
        self.run_info = self._label('선택한 지수를 밴드 연산으로 계산합니다.', muted=True)
        lay.addWidget(self.run_info)
        v.addWidget(g)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        v.addWidget(self.progress)
        btn = QPushButton('배경지도 추가 (Esri 일반 지도, API 키 불필요)')
        btn.clicked.connect(self.add_basemap)
        v.addWidget(btn)
        v.addStretch(1)
        return w

    def _tab_cls(self):
        w = QWidget()
        v = QVBoxLayout(w)
        self.cls_empty = self._label('4단계 ‘분석 실행’ 후 여기에서 임계값을 조정합니다.', muted=True)
        v.addWidget(self.cls_empty)

        g, lay = self._group('임계값 설정')
        self.badge = QLabel()
        lay.addWidget(self.badge)
        row = QHBoxLayout()
        self.cls_combo = QComboBox()
        self.cls_combo.currentIndexChanged.connect(lambda _i: self.set_active(self.cls_combo.currentData()))
        self.dir_combo = QComboBox()
        self.dir_combo.addItem('이상 (≥)', 'ge')
        self.dir_combo.addItem('이하 (≤)', 'le')
        self.dir_combo.currentIndexChanged.connect(self.on_dir)
        row.addWidget(self.cls_combo, 1)
        row.addWidget(self.dir_combo)
        lay.addLayout(row)
        row = QHBoxLayout()
        self.thr_slider = QSlider(Qt.Orientation.Horizontal)
        self.thr_slider.setRange(-100, 100)
        self.thr_slider.valueChanged.connect(lambda val: self.on_thr(val / 100))
        self.thr_spin = QDoubleSpinBox()
        self.thr_spin.setRange(-1, 1)
        self.thr_spin.setSingleStep(0.01)
        self.thr_spin.setDecimals(2)
        self.thr_spin.valueChanged.connect(self.on_thr)
        row.addWidget(self.thr_slider, 1)
        row.addWidget(self.thr_spin)
        lay.addLayout(row)
        self.hist = HistWidget()
        lay.addWidget(self.hist)
        self.cls_info = self._label()
        lay.addWidget(self.cls_info)
        self.below_chk = QCheckBox('미리보기에서 미분류 영역 회색 표시')
        self.below_chk.setChecked(True)
        self.below_chk.toggled.connect(lambda _b: self.render_timer.start())
        lay.addWidget(self.below_chk)
        self.btn_confirm = QPushButton('임계값 확정')
        self.btn_confirm.clicked.connect(self.confirm_threshold)
        lay.addWidget(self.btn_confirm)
        self.cls_group = g
        v.addWidget(g)

        g, lay = self._group('범례 · 결과 투명도')
        self.legend = self._label()
        lay.addWidget(self.legend)
        row = QHBoxLayout()
        self.op_slider = QSlider(Qt.Orientation.Horizontal)
        self.op_slider.setRange(0, 100)
        self.op_slider.setSingleStep(5)
        self.op_slider.setValue(10)
        self.op_label = QLabel('10%')
        self.op_slider.valueChanged.connect(self.on_opacity)
        row.addWidget(QLabel('투명도'))
        row.addWidget(self.op_slider, 1)
        row.addWidget(self.op_label)
        lay.addLayout(row)
        self.legend_group = g
        v.addWidget(g)
        v.addStretch(1)
        return w

    def _table(self, headers):
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        t.setMinimumHeight(150)
        return t

    def _tab_stat(self):
        w = QWidget()
        v = QVBoxLayout(w)

        g, lay = self._group('행정구역 (시·군)')
        self.admin_idx = QLabel()
        lay.addWidget(self.admin_idx)
        self.btn_pick = QPushButton('🖱 시·군 선택 도구')
        self.btn_pick.setCheckable(True)
        self.btn_pick.toggled.connect(self.on_pick_toggled)
        lay.addWidget(self.btn_pick)
        lay.addWidget(self._label('지도에서 마우스를 올리면 시·군 이름이 보이고, 클릭하면 선택(적색)되며 '
                                  '다시 클릭하면 해제됩니다.', muted=True))
        self.admin_table = self._table(['행정구역', '행정구역\n면적', '영상\n유효', '분석\n면적', '비율\n(%)'])
        self.admin_table.cellClicked.connect(self.zoom_region_row)
        lay.addWidget(self.admin_table)
        self.admin_note = self._label('', muted=True)
        lay.addWidget(self.admin_note)
        row = QHBoxLayout()
        self.btn_admin_clear = QPushButton('선택 해제')
        self.btn_admin_clear.clicked.connect(self.clear_regions)
        self.btn_csv = QPushButton('CSV 저장')
        self.btn_csv.clicked.connect(self.save_csv)
        row.addWidget(self.btn_admin_clear)
        row.addWidget(self.btn_csv)
        lay.addLayout(row)
        v.addWidget(g)

        g, lay = self._group('직접 그린 영역')
        row = QHBoxLayout()
        self.btn_poly = QPushButton('⬠ 폴리곤')
        self.btn_poly.clicked.connect(lambda: self.start_draw(False))
        self.btn_rect = QPushButton('▭ 사각형')
        self.btn_rect.clicked.connect(lambda: self.start_draw(True))
        self.btn_draw_clear = QPushButton('지우기')
        self.btn_draw_clear.clicked.connect(self.clear_drawn)
        row.addWidget(self.btn_poly)
        row.addWidget(self.btn_rect)
        row.addWidget(self.btn_draw_clear)
        lay.addLayout(row)
        lay.addWidget(self._label('폴리곤: 왼쪽 클릭으로 점 추가 · 오른쪽 클릭(더블클릭)으로 완료 · Esc 취소\n'
                                  '사각형: 드래그', muted=True))
        self.draw_table = self._table(['영역', '면적\n(km²)', '분석 면적\n(km²)', '비율\n(%)', '평균값'])
        self.draw_table.cellClicked.connect(self.zoom_draw_row)
        lay.addWidget(self.draw_table)
        self.stat_info = self._label('', muted=True)
        lay.addWidget(self.stat_info)
        v.addWidget(g)
        v.addStretch(1)
        return w

    # ─────────────────────────── 공통 ───────────────────────────
    def busy(self, msg, pct=None):
        if msg is False:
            self.progress.setVisible(False)
            QApplication.restoreOverrideCursor()
            return
        if not self.progress.isVisible():
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.progress.setVisible(True)
        self.progress.setFormat(msg + '  %p%')
        self.progress.setValue(int(pct or 0))
        QApplication.processEvents()

    def error(self, msg):
        QMessageBox.warning(self, 'Landsat 지수 분석', msg)

    def layer(self, lid):
        return self.project.mapLayer(lid) if lid else None

    def group(self):
        root = self.project.layerTreeRoot()
        g = root.findGroup(GROUP_NAME)
        return g or root.insertGroup(0, GROUP_NAME)

    def current_key(self):
        return self.index_combo.currentData()

    def need_bands(self, key=None):
        return sorted(set(INDICES[key or self.current_key()]['bands']))

    def bands_ready(self, key=None):
        return self.grid is not None and all(b in self.grid.bands for b in self.need_bands(key))

    def update_ui(self):
        key = self.current_key()
        d = INDICES[key]
        self.formula.setText(f'{key} = {d["formula"]}')
        need = self.need_bands()
        self.need_label.setText('필요 밴드: ' + ', '.join(
            f'B{b} {BAND_INFO[b].split(" ")[0]}' + (' ✔' if self.grid and b in self.grid.bands else '') for b in need))
        self.btn_load.setEnabled(self.scene is not None)
        self.btn_run.setEnabled(self.scene is not None)
        has = bool(self.results)
        self.cls_empty.setVisible(not has)
        self.cls_group.setEnabled(has)
        self.legend_group.setEnabled(has)
        r = self.results.get(self.active)
        conf = r is not None and r.confirmed is not None
        for b in (self.btn_poly, self.btn_rect, self.btn_draw_clear):
            b.setEnabled(conf)

    # ─────────────────────── 1단계: 폴더 ───────────────────────
    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Landsat 장면 폴더 선택', self.folder_edit.text())
        if not folder:
            return
        self.busy('폴더 읽는 중…', 5)
        try:
            scenes = core.scan_folder(folder)
        finally:
            self.busy(False)
        if not scenes:
            self.error('Landsat 밴드 파일(*_SR_B4.TIF, *_B4.TIF 등)을 찾지 못했습니다.\n'
                       '압축(zip/gz)은 먼저 풀어 주세요. (USGS .tar 는 그대로 사용 가능)')
            return
        self.folder_edit.setText(folder)
        self.scenes = scenes
        self.scene_combo.blockSignals(True)
        self.scene_combo.clear()
        for sid in scenes:
            self.scene_combo.addItem(sid, sid)
        self.scene_combo.blockSignals(False)
        self.scene_combo.setVisible(len(scenes) > 1)
        self.select_scene()

    def select_scene(self, *_):
        sid = self.scene_combo.currentData()
        if not sid:
            return
        self.reset_loaded()
        self.scene = sc = self.scenes[sid]
        self.scene_info.setText(sc.describe())
        self.scene_info.setToolTip(sid)
        self.cloud_chk.setEnabled(sc.qa is not None)
        self.cloud_chk.setChecked(sc.qa is not None)
        # 장면에 없는 밴드를 쓰는 지수는 비활성
        model = self.index_combo.model()
        first_ok = None
        for i in range(self.index_combo.count()):
            k = self.index_combo.itemData(i)
            ok = all(b in sc.bands for b in INDICES[k]['bands'])
            if isinstance(model, QStandardItemModel):
                model.item(i).setEnabled(ok)
            if ok and first_ok is None:
                first_ok = i
        cur = self.current_key()
        if not all(b in sc.bands for b in INDICES[cur]['bands']) and first_ok is not None:
            self.index_combo.setCurrentIndex(first_ok)
        self.update_ui()

    def reset_loaded(self):
        for r in self.results.values():
            if self.layer(r.layer_id):
                self.project.removeMapLayer(r.layer_id)
        for lid in self.band_layers.values():
            if self.layer(lid):
                self.project.removeMapLayer(lid)
        self.grid = None
        self.results = {}
        self.band_layers = {}
        self.active = None
        self.load_info.setText('')
        self.run_info.setText('선택한 지수를 밴드 연산으로 계산합니다.')
        self.cls_combo.blockSignals(True)
        self.cls_combo.clear()
        self.cls_combo.blockSignals(False)
        self.hist.set_result(None)
        self.badge.setText('')
        self.cls_info.setText('')
        self.legend.setText('')
        self.reset_stats()
        self.update_ui()

    # ─────────────────────── 2단계: 지수 ───────────────────────
    def on_index_changed(self, *_):
        self.update_ui()
        key = self.current_key()
        if key in self.results:
            self.set_active(key)
        elif self.grid is not None and not self.bands_ready():
            self.load_info.setText('<span style="color:#b45309">선택한 지수에 필요한 밴드를 4단계 실행 시 '
                                   '추가로 불러옵니다.</span>')

    # ─────────────────────── 3단계: 영상 불러오기 ───────────────────────
    def load_images(self, keep=False):
        """keep=True 이면 같은 장면·해상도에서 빠진 밴드만 추가로 읽는다."""
        sc = self.scene
        if sc is None:
            return False
        res = self.res_combo.currentData()
        need = self.need_bands()
        use_qa = self.cloud_chk.isChecked() and sc.qa is not None
        same = (keep and self.grid is not None and self.grid.res == res and self.grid.scene_id == sc.id
                and (self.grid.qa is not None) == use_qa)
        try:
            self.busy('영상 정보 읽는 중…', 2)
            if same:
                g = self.grid
            else:
                g = core.open_grid(sc, need[0], res)
                g.res, g.scene_id = res, sc.id
                if g.W * g.H > 40e6:
                    self.busy(False)
                    ans = QMessageBox.question(self, 'Landsat 지수 분석',
                                               f'분석 격자가 {g.W:,}×{g.H:,} 픽셀로 큽니다. 메모리를 많이 사용할 수 '
                                               '있습니다. 계속할까요?')
                    if ans != QMessageBox.StandardButton.Yes:
                        return False
            todo = [b for b in need if b not in g.bands]
            scale, unit = core.band_scale(sc, todo)
            total = len(todo) + (1 if use_qa and g.qa is None else 0)
            for i, b in enumerate(todo):
                self.busy(f'밴드 {b} · {BAND_INFO[b]} 읽는 중… ({i + 1}/{total})', 5 + 90 * i / max(total, 1))
                g.bands[b] = (core.read_band(sc.bands[b], g),) + tuple(scale[b])
            if use_qa and g.qa is None:
                self.busy(f'QA_PIXEL 읽는 중… ({total}/{total})', 95)
                g.qa = core.read_band(sc.qa, g)
            if todo:
                g.scale_unit = unit
        except Exception as err:     # noqa: BLE001 — 사용자에게 그대로 알림
            self.busy(False)
            self.error(f'영상을 불러오지 못했습니다:\n{err}')
            return False
        self.busy(False)
        if not same:
            self.reset_loaded()
            self.grid = g
        self.load_info.setText(f'<b>{abs(g.gt[1]):,.0f} m</b> 격자 · {g.W:,} × {g.H:,} px · EPSG:{g.epsg}<br>'
                               f'{g.scale_unit}{" · 구름 마스킹 적용" if g.qa is not None else ""}')
        self.update_ui()
        return True

    # ─────────────────────── 4단계: 분석 실행 ───────────────────────
    def run_analysis(self):
        key = self.current_key()
        if not self.bands_ready() or self.grid.res != self.res_combo.currentData():
            if not self.load_images(keep=True):
                return
        # 분석을 다시 실행하면 6단계 통계(선택한 시·군, 직접 그린 영역)를 초기화
        self.reset_stats()
        first = not self.results
        try:
            if key not in self.results:            # 이미 계산·확정한 지수는 유지
                self.busy(f'{key} 계산 중…', 30)
                r = core.compute_index(key, self.grid)
                self.busy(f'{key} 결과 저장 중…', 80)
                tag = (self.scene.date or self.scene.id).replace('-', '')
                r.path = os.path.join(self.outdir, f'{key}_{tag}_{self.grid.res}m.tif')
                core.write_geotiff(r.path, self.grid, r.data)
                self.results[key] = r
            self.busy(False)
        except Exception as err:     # noqa: BLE001
            self.busy(False)
            self.error(f'분석 중 오류:\n{err}')
            return
        r = self.results[key]
        self.ensure_result_layer(r)
        self.add_band_layers(key)
        self.ensure_admin_layer()
        self.run_info.setText(f'<b>{key}</b> 평균 {fmt(r.mean, 3)} ({fmt(r.vmin)} ~ {fmt(r.vmax)})<br>'
                              f'<span style="color:#6b7686">저장 위치: {r.path}</span>')
        self.cls_combo.blockSignals(True)
        self.cls_combo.clear()
        for k in INDICES:
            if k in self.results:
                self.cls_combo.addItem(f'{k} · {INDICES[k]["name"]}', k)
        self.cls_combo.blockSignals(False)
        self.set_active(key)
        if first:
            lyr = self.layer(r.layer_id)
            ct = QgsCoordinateTransform(lyr.crs(), self.canvas.mapSettings().destinationCrs(), self.project)
            self.canvas.setExtent(ct.transformBoundingBox(lyr.extent()))
            self.canvas.refresh()
        self.tabs.setCurrentIndex(1)

    def ensure_result_layer(self, r):
        if self.layer(r.layer_id):
            return
        lyr = QgsRasterLayer(r.path, f'{r.key} 결과')
        self.project.addMapLayer(lyr, False)
        g = self.group()
        pos = sum(1 for n in g.children() if getattr(n, 'layer', lambda: None)() is not None
                  and isinstance(n.layer(), QgsVectorLayer))
        g.insertLayer(pos, lyr)
        r.layer_id = lyr.id()

    def add_band_layers(self, key):
        """밴드 A·B 원본을 '밴드 원본' 그룹에 꺼진 상태로 추가 (웹 버전 왼쪽 두 지도 대신)"""
        g = self.group()
        sub = g.findGroup('밴드 원본') or g.addGroup('밴드 원본')
        for b in INDICES[key]['bands']:
            if self.layer(self.band_layers.get(b)):
                continue
            lyr = QgsRasterLayer(self.scene.bands[b], f'B{b} {BAND_INFO[b]}')
            if not lyr.isValid():
                continue
            self.project.addMapLayer(lyr, False)
            sub.addLayer(lyr).setItemVisibilityChecked(False)
            self.band_layers[b] = lyr.id()
        sub.setExpanded(False)

    def add_basemap(self):
        for lyr in self.project.mapLayers().values():
            if 'World_Street_Map' in lyr.source():
                return
        lyr = QgsRasterLayer(ESRI_STREET, 'Esri 일반 지도', 'wms')
        if not lyr.isValid():
            self.error('배경지도를 추가하지 못했습니다. 인터넷 연결을 확인하세요.')
            return
        self.project.addMapLayer(lyr, False)
        root = self.project.layerTreeRoot()
        root.insertLayer(len(root.children()), lyr)

    # ─────────────────────── 5단계: 분류 ───────────────────────
    def set_active(self, key):
        if not key or key not in self.results:
            return
        self.active = key
        r = self.results[key]
        for k, other in self.results.items():
            node = self.project.layerTreeRoot().findLayer(other.layer_id) if other.layer_id else None
            if node:
                node.setItemVisibilityChecked(k == key)
        for w, val in ((self.cls_combo, key), (self.dir_combo, r.dir)):
            w.blockSignals(True)
            w.setCurrentIndex(w.findData(val))
            w.blockSignals(False)
        self._set_thr_widgets(r.thr)
        self.render_active()
        self.refresh_stats()
        self.update_ui()

    def _set_thr_widgets(self, thr):
        for w, val in ((self.thr_slider, int(round(thr * 100))), (self.thr_spin, thr)):
            w.blockSignals(True)
            w.setValue(val)
            w.blockSignals(False)

    def on_thr(self, val):
        r = self.results.get(self.active)
        if r is None:
            return
        r.thr = round(float(val), 2)
        self._set_thr_widgets(r.thr)
        self.render_timer.start()

    def on_dir(self, *_):
        r = self.results.get(self.active)
        if r is None:
            return
        r.dir = self.dir_combo.currentData()
        self.render_timer.start()

    def on_opacity(self, pct):
        self.op_label.setText(f'{pct}%')
        lyr = self.layer(self.results[self.active].layer_id) if self.active in self.results else None
        if lyr and lyr.renderer():
            lyr.renderer().setOpacity(1 - pct / 100)
            lyr.triggerRepaint()

    def render_active(self):
        r = self.results.get(self.active)
        if r is None:
            return
        self.style_result(r)
        self.hist.set_result(r)
        c = r.class_count()
        self.cls_info.setText(f'분류 면적 (장면 전체): <b>{fmt_area(c * self.grid.pixA)}</b> · '
                              f'유효 영역의 <b>{fmt(100 * c / r.valid if r.valid else 0, 1)}%</b>')
        if r.confirmed is None:
            self.badge.setText('<span style="color:#6b7686">미확정</span>')
        elif r.is_class_view():
            self.badge.setText(f'<b style="color:#15803d">확정 {dir_sym(r.dir)} {fmt(r.thr)}</b>')
        else:
            cthr, cdir = r.confirmed
            self.badge.setText(f'<b style="color:#b45309">변경됨 · 확정값 {dir_sym(cdir)} {fmt(cthr)}</b>')
        if r.is_class_view():
            self.legend.setText(f'<b>{r.key} 분류 결과</b><br>■ {r.key} {dir_sym(r.dir)} {fmt(r.thr)} (분류 영역) · '
                                '□ 나머지 지역(흰색)')
        else:
            self.legend.setText(f'<b>{r.key} · {INDICES[r.key]["name"]}</b><br>빨강(낮음 {fmt(r.vmin)}) → '
                                f'녹색(높음 {fmt(r.vmax)}) · 임계값 {dir_sym(r.dir)} {fmt(r.thr)}')

    def style_result(self, r):
        lyr = self.layer(r.layer_id)
        if lyr is None:
            return
        Item = QgsColorRampShader.ColorRampItem
        shader = QgsColorRampShader()
        eps = 1e-6
        if r.is_class_view():               # 확정 결과: 분류 영역 = 지수별 색, 나머지 = 흰색
            shader.setColorRampType(RAMP_DISCRETE)
            cc, white = QColor(*CLASS_COLOR[r.key]), QColor(255, 255, 255)
            label = f'{r.key} {dir_sym(r.dir)} {fmt(r.thr)}'
            if r.dir == 'ge':
                items = [Item(r.thr - eps, white, '나머지 지역'), Item(float('inf'), cc, label)]
            else:
                items = [Item(r.thr, cc, label), Item(float('inf'), white, '나머지 지역')]
        else:                                # 미리보기: 통과 구간은 RdYlGn, 나머지는 반투명 회색
            shader.setColorRampType(RAMP_LINEAR)
            gray = QColor(128, 128, 128, 90 if self.below_chk.isChecked() else 0)
            lo, hi = r.vmin, r.vmax

            def item(v):
                return Item(v, QColor(*ramp_color((v - lo) / (hi - lo))), fmt(v))

            stops = [lo + (hi - lo) * i / 10 for i in range(11)]
            if r.dir == 'ge':
                items = [Item(-1, gray, '미분류'), Item(r.thr - eps, gray, '')] if r.thr > -1 + eps else []
                items += [item(r.thr)] + [item(v) for v in stops if v > r.thr]
            else:
                items = [item(v) for v in stops if v < r.thr] + [item(r.thr)]
                if r.thr < 1 - eps:
                    items += [Item(r.thr + eps, gray, ''), Item(1, gray, '미분류')]
        shader.setColorRampItemList(items)
        fn = QgsRasterShader()
        fn.setRasterShaderFunction(shader)
        ren = QgsSingleBandPseudoColorRenderer(lyr.dataProvider(), 1, fn)
        ren.setClassificationMin(-1)
        ren.setClassificationMax(1)
        ren.setOpacity(1 - self.op_slider.value() / 100)
        lyr.setRenderer(ren)
        lyr.triggerRepaint()
        self.iface.layerTreeView().refreshLayerSymbology(lyr.id())

    def confirm_threshold(self):
        r = self.results.get(self.active)
        if r is None:
            return
        r.confirmed = (r.thr, r.dir)
        self.render_active()
        self.refresh_stats()
        self.update_ui()
        self.tabs.setCurrentIndex(2)
        self.btn_pick.setChecked(True)

    # ─────────────────────── 6단계: 행정구역 ───────────────────────
    def ensure_admin_layer(self):
        lyr = self.layer(self.admin_id)
        if lyr:
            return lyr
        lyr = QgsVectorLayer(os.path.join(PLUGIN_DIR, 'data', 'sigungu.geojson'), ADMIN_NAME, 'ogr')
        if not lyr.isValid():
            self.error('행정구역 경계(data/sigungu.geojson)를 불러오지 못했습니다.')
            return None
        lyr.setDisplayExpression('"key"')
        lyr.setMapTipTemplate('[% "key" %]')
        self.project.addMapLayer(lyr, False)
        self.group().insertLayer(0, lyr)
        self.admin_id = lyr.id()
        self.admin_geoms = {f.id(): (f['key'], f.geometry(), f['area_km2']) for f in lyr.getFeatures()}
        self.admin_index = QgsSpatialIndex(lyr.getFeatures())
        self.admin_sel = {}
        self.style_admin()
        return lyr

    def style_admin(self):
        lyr = self.layer(self.admin_id)
        if lyr is None:
            return
        base = QgsFillSymbol.createSimple({'color': '0,0,0,0', 'outline_color': '34,34,34,230',
                                           'outline_width': '0.3'})
        sel = QgsFillSymbol.createSimple({'color': '229,57,53,89', 'outline_color': '183,28,28,255',
                                          'outline_width': '0.7'})       # 반투명 적색 (뒤의 분석 결과가 비침)
        root = QgsRuleBasedRenderer.Rule(None)
        if self.admin_sel:
            keys = ','.join("'%s'" % k.replace("'", "''") for k in self.admin_sel)
            flt = f'"key" IN ({keys})'
            root.appendChild(QgsRuleBasedRenderer.Rule(base, 0, 0, f'NOT ({flt})', '시·군 경계'))
            root.appendChild(QgsRuleBasedRenderer.Rule(sel, 0, 0, flt, '선택한 시·군'))
            # 선택된 시·군만 이름표 표시
            pal = QgsPalLayerSettings()
            pal.isExpression = True
            pal.fieldName = f'CASE WHEN {flt} THEN "key" END'
            pal.placement = OVER_POINT
            pal.centroidInside = True
            tf = QgsTextFormat()
            font = QFont()
            font.setBold(True)
            tf.setFont(font)
            tf.setSize(9)
            tf.setColor(QColor(183, 28, 28))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.2)
            buf.setColor(QColor(255, 255, 255))
            tf.setBuffer(buf)
            pal.setFormat(tf)
            lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            lyr.setLabelsEnabled(True)
        else:
            root.appendChild(QgsRuleBasedRenderer.Rule(base, 0, 0, '', '시·군 경계'))
            lyr.setLabelsEnabled(False)
        lyr.setRenderer(QgsRuleBasedRenderer(root))
        lyr.triggerRepaint()
        self.iface.layerTreeView().refreshLayerSymbology(lyr.id())

    def region_at(self, pt):
        """지도 좌표 → (시·군 이름, fid)"""
        lyr = self.layer(self.admin_id)
        if lyr is None or self.admin_index is None:
            return None
        ct = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(), lyr.crs(), self.project)
        try:
            p = ct.transform(pt)
        except Exception:            # noqa: BLE001 — 변환 불가 지점
            return None
        for fid in self.admin_index.intersects(QgsRectangle(p.x(), p.y(), p.x(), p.y())):
            key, geom, _a = self.admin_geoms[fid]
            if geom.contains(QgsPointXY(p)):
                return key, fid
        return None

    def toggle_region(self, fid):
        key = self.admin_geoms[fid][0]
        if key in self.admin_sel:
            del self.admin_sel[key]
        else:
            self.admin_sel[key] = fid
        self.style_admin()
        self.refresh_admin_table()

    def clear_regions(self):
        self.admin_sel = {}
        self.style_admin()
        self.refresh_admin_table()

    def on_pick_toggled(self, on):
        if on:
            if self.ensure_admin_layer() is None:
                self.btn_pick.setChecked(False)
                return
            self.canvas.setMapTool(self.region_tool)
        elif self.canvas.mapTool() is self.region_tool:
            self.canvas.unsetMapTool(self.region_tool)

    def _on_tool_changed(self, new, _old=None):
        if new is not self.region_tool and self.btn_pick.isChecked():
            self.btn_pick.blockSignals(True)
            self.btn_pick.setChecked(False)
            self.btn_pick.blockSignals(False)

    def _to_grid_wkb(self, geom, crs):
        g = type(geom)(geom)
        g.transform(QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem.fromWkt(self.grid.wkt), self.project))
        return g.asWkb()

    def refresh_admin_table(self):
        r = self.results.get(self.active)
        conf = r is not None and r.confirmed is not None
        if conf:
            self.admin_idx.setText(f'<b>{r.key} {dir_sym(r.confirmed[1])} {fmt(r.confirmed[0])}</b>')
        else:
            self.admin_idx.setText(f'{r.key} 미확정' if r else '분석 전')
        self.btn_admin_clear.setEnabled(bool(self.admin_sel))
        self.btn_csv.setEnabled(bool(self.admin_sel))
        t = self.admin_table
        t.setRowCount(0)
        self.admin_rows = []
        if not self.admin_sel:
            self.admin_note.setText('선택된 시·군이 없습니다. · 면적 단위: km²')
            return
        lyr = self.layer(self.admin_id)
        if lyr is None:                       # 사용자가 행정구역 레이어를 지운 경우
            self.admin_sel = {}
            self.refresh_admin_table()
            return
        A = self.grid.pixA if self.grid else 0
        for key, fid in self.admin_sel.items():
            _k, geom, area_km2 = self.admin_geoms[fid]
            row = dict(name=key, area=float(area_km2), valid=None, cls=None, fid=fid)
            if self.grid is not None and r is not None:
                st = core.zonal(self.grid, self._to_grid_wkb(geom, lyr.crs()), r)
                row['valid'] = st['valid'] * A / 1e6
                if conf:
                    row['cls'] = st['pass_'] * A / 1e6
            self.admin_rows.append(row)
        rows = list(self.admin_rows)
        if len(rows) > 1:
            def total(f):
                return None if any(x[f] is None for x in rows) else sum(x[f] for x in rows)
            rows.append(dict(name=f'합계 {len(rows)}개', area=total('area'), valid=total('valid'),
                             cls=total('cls'), fid=None))
        for x in rows:
            i = t.rowCount()
            t.insertRow(i)
            vals = [x['name'], fmt(x['area']), fmt(x['valid']), fmt(x['cls']), pct_of(x['cls'], x['area'])]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                if c:
                    align_right(it)
                if c == 3:
                    it.setForeground(QColor(180, 83, 9))
                if x['fid'] is None:
                    f = it.font()
                    f.setBold(True)
                    it.setFont(f)
                t.setItem(i, c, it)
        t.resizeColumnsToContents()
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.admin_note.setText('면적 단위: km² · 비율 = 분석 면적 ÷ 행정구역 면적 · 영상 밖·구름 영역은 분석 면적에서 제외'
                                if conf else '면적 단위: km² · 5단계에서 임계값을 확정하면 분석 면적이 계산됩니다.')

    def zoom_region_row(self, row, _col):
        if row >= len(self.admin_rows):
            return
        lyr = self.layer(self.admin_id)
        geom = self.admin_geoms[self.admin_rows[row]['fid']][1]
        ct = QgsCoordinateTransform(lyr.crs(), self.canvas.mapSettings().destinationCrs(), self.project)
        ext = ct.transformBoundingBox(geom.boundingBox())
        ext.scale(1.3)
        self.canvas.setExtent(ext)
        self.canvas.refresh()

    def save_csv(self):
        if not self.admin_rows:
            return
        r = self.results.get(self.active)
        name = f'행정구역_통계_{self.active or "결과"}.csv'
        path, _f = QFileDialog.getSaveFileName(self, 'CSV 저장', os.path.join(os.path.expanduser('~'), name),
                                               'CSV (*.csv)')
        if not path:
            return
        cond = ''
        if r is not None and r.confirmed is not None:
            cond = f'{r.key} {">=" if r.confirmed[1] == "ge" else "<="} {r.confirmed[0]}'

        def n(v):
            return '' if v is None else f'{v:.4f}'
        with open(path, 'w', newline='', encoding='utf-8-sig') as fp:
            w = csv.writer(fp)
            w.writerow(['행정구역', '행정구역 면적(km2)', '영상 유효 면적(km2)', '분석 면적(km2)', '비율(%)', '분석 조건'])
            for x in self.admin_rows:
                w.writerow([x['name'], n(x['area']), n(x['valid']), n(x['cls']),
                            '' if x['cls'] is None else f'{100 * x["cls"] / x["area"]:.2f}', cond])

    # ─────────────────────── 6단계: 직접 그린 영역 ───────────────────────
    def ensure_draw_layer(self):
        lyr = self.layer(self.draw_id)
        if lyr:
            return lyr
        crs = self.canvas.mapSettings().destinationCrs()
        lyr = QgsVectorLayer('Polygon', DRAW_NAME, 'memory')
        lyr.setCrs(crs)
        lyr.dataProvider().addAttributes([QgsField('id', INT_TYPE)])
        lyr.updateFields()
        lyr.setRenderer(QgsRuleBasedRenderer(self._draw_rule()))
        pal = QgsPalLayerSettings()
        pal.isExpression = True
        pal.fieldName = "'영역 ' || \"id\""
        pal.placement = OVER_POINT
        tf = QgsTextFormat()
        font = QFont()
        font.setBold(True)
        tf.setFont(font)
        tf.setSize(8)
        tf.setColor(QColor(255, 255, 255))
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(1.2)
        buf.setColor(QColor(19, 35, 58))
        tf.setBuffer(buf)
        pal.setFormat(tf)
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        lyr.setLabelsEnabled(True)
        self.project.addMapLayer(lyr, False)
        self.group().insertLayer(0, lyr)
        self.draw_id = lyr.id()
        return lyr

    @staticmethod
    def _draw_rule():
        sym = QgsFillSymbol.createSimple({'color': '31,95,191,15', 'outline_color': '31,95,191,255',
                                          'outline_width': '0.5'})
        root = QgsRuleBasedRenderer.Rule(None)
        root.appendChild(QgsRuleBasedRenderer.Rule(sym, 0, 0, '', '직접 그린 영역'))
        return root

    def start_draw(self, rect):
        self.draw_tool = DrawTool(self.canvas, rect, self.on_drawn)
        self.canvas.setMapTool(self.draw_tool)

    def on_drawn(self, geom):
        lyr = self.ensure_draw_layer()
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        if canvas_crs != lyr.crs():
            geom.transform(QgsCoordinateTransform(canvas_crs, lyr.crs(), self.project))
        self.poly_count += 1
        f = QgsFeature(lyr.fields())
        f.setGeometry(geom)
        f['id'] = self.poly_count
        lyr.dataProvider().addFeatures([f])
        lyr.updateExtents()
        lyr.triggerRepaint()
        self.refresh_draw_table()

    def clear_drawn(self):
        lyr = self.layer(self.draw_id)
        if lyr:
            lyr.dataProvider().truncate()
            lyr.triggerRepaint()
        self.poly_count = 0
        self.refresh_draw_table()

    def refresh_draw_table(self):
        t = self.draw_table
        t.setRowCount(0)
        self.draw_rows = []
        lyr = self.layer(self.draw_id)
        r = self.results.get(self.active)
        conf = r is not None and r.confirmed is not None
        feats = sorted(lyr.getFeatures(), key=lambda f: f['id']) if lyr else []
        if not feats:
            self.stat_info.setText('⬠ 폴리곤 또는 ▭ 사각형으로 영역을 그려 보세요.')
            return
        A = self.grid.pixA if self.grid else 0
        for f in feats:
            area = cls = mean = None
            if self.grid is not None:
                st = core.zonal(self.grid, self._to_grid_wkb(f.geometry(), lyr.crs()), r)
                area = st['area'] / 1e6
                if r is not None and st['valid']:
                    mean = st['sum'] / st['valid']
                if conf:
                    cls = st['pass_'] * A / 1e6
            self.draw_rows.append(f.id())
            i = t.rowCount()
            t.insertRow(i)
            vals = [f'영역 {f["id"]}', fmt(area), fmt(cls), pct_of(cls, area), fmt(mean, 3)]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                if c:
                    align_right(it)
                if c == 2:
                    it.setForeground(QColor(180, 83, 9))
                t.setItem(i, c, it)
        t.resizeColumnsToContents()
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.stat_info.setText(f'{r.key} {dir_sym(r.confirmed[1])} {fmt(r.confirmed[0])} 기준 · 행을 클릭하면 '
                               '해당 영역으로 이동합니다.' if conf else
                               '5단계에서 임계값을 확정하면 분석 면적이 계산됩니다.')

    def zoom_draw_row(self, row, _col):
        lyr = self.layer(self.draw_id)
        if lyr is None or row >= len(self.draw_rows):
            return
        f = lyr.getFeature(self.draw_rows[row])
        ct = QgsCoordinateTransform(lyr.crs(), self.canvas.mapSettings().destinationCrs(), self.project)
        ext = ct.transformBoundingBox(f.geometry().boundingBox())
        ext.scale(1.4)
        self.canvas.setExtent(ext)
        self.canvas.refresh()

    # ─────────────────────── 통계 갱신 · 초기화 ───────────────────────
    def refresh_stats(self):
        self.refresh_admin_table()
        self.refresh_draw_table()

    def reset_stats(self):
        self.admin_sel = {}
        self.style_admin()
        lyr = self.layer(self.draw_id)
        if lyr:
            lyr.dataProvider().truncate()
            lyr.triggerRepaint()
        self.poly_count = 0
        self.refresh_stats()

    def cleanup(self):
        for tool in (self.region_tool, self.draw_tool):
            if tool is not None and self.canvas.mapTool() is tool:
                self.canvas.unsetMapTool(tool)
        try:
            self.canvas.mapToolSet.disconnect(self._on_tool_changed)
        except (TypeError, RuntimeError):
            pass
