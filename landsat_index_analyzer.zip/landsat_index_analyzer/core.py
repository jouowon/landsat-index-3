# -*- coding: utf-8 -*-
"""
Landsat 8·9 다중분광지수 계산 모듈 (웹 버전 app.js 의 계산 부분을 GDAL·numpy 로 옮김)
  장면 탐색 → 밴드 읽기(해상도 축소) → 지수 계산 → 임계값 분류 → 영역 통계
"""
import math
import os
import re
import tarfile

import numpy as np
from osgeo import gdal, ogr, osr

gdal.UseExceptions()

BAND_INFO = {
    1: 'Coastal (연안/에어로졸)',
    2: 'Blue (청색)',
    3: 'Green (녹색)',
    4: 'Red (적색)',
    5: 'NIR (근적외)',
    6: 'SWIR1 (단파적외 1)',
    7: 'SWIR2 (단파적외 2)',
}

# bands: [밴드 A, 밴드 B]
INDICES = {
    'NDVI':  dict(name='정규식생지수',      bands=(5, 4), formula='(NIR − Red) / (NIR + Red)',             thr=0.3),
    'GNDVI': dict(name='녹색 정규식생지수', bands=(5, 3), formula='(NIR − Green) / (NIR + Green)',         thr=0.3),
    'SAVI':  dict(name='토양보정 식생지수', bands=(5, 4), formula='1.5 × (NIR − Red) / (NIR + Red + 0.5)', thr=0.2),
    'NBR':   dict(name='정규탄화지수',      bands=(5, 7), formula='(NIR − SWIR2) / (NIR + SWIR2)',         thr=0.1),
    'NDMI':  dict(name='정규수분함량지수',  bands=(5, 6), formula='(NIR − SWIR1) / (NIR + SWIR1)',         thr=0.1),
    'NDWI':  dict(name='정규수체지수',      bands=(3, 5), formula='(Green − NIR) / (Green + NIR)',         thr=0.0),
    'MNDWI': dict(name='수정 정규수체지수', bands=(3, 6), formula='(Green − SWIR1) / (Green + SWIR1)',     thr=0.0),
    'NDBI':  dict(name='정규시가화지수',    bands=(6, 5), formula='(SWIR1 − NIR) / (SWIR1 + NIR)',         thr=0.0),
}

# 임계값 확정 후 분류 영역 표시 색 (나머지 지역은 흰색)
CLASS_COLOR = {
    'NDVI': (26, 150, 65), 'GNDVI': (26, 150, 65), 'SAVI': (26, 150, 65),
    'NBR': (215, 25, 28),
    'NDWI': (33, 102, 172), 'MNDWI': (33, 102, 172),
    'NDBI': (245, 130, 32),
    'NDMI': (0, 150, 160),
}

# 빨강 → 노랑 → 녹색 (RdYlGn)
RAMP = [
    (165, 0, 38), (215, 48, 39), (244, 109, 67), (253, 174, 97), (254, 224, 139), (255, 255, 191),
    (217, 239, 139), (166, 217, 106), (102, 189, 99), (26, 152, 80), (0, 104, 55),
]

# Collection 2 Level-2 지표면 반사율 환산 계수
L2_SCALE = (0.0000275, -0.2)
# QA_PIXEL: bit0 fill, bit1 dilated cloud, bit2 cirrus, bit3 cloud, bit4 cloud shadow
QA_MASK = 0b11111
HIST_BINS = 200

PRODUCT_RE = re.compile(r'^(L[COTE]0\d_[A-Z0-9]{4}_\d{6}_\d{8}_\d{8}_\d{2}_[A-Z0-9]{2})_(.+)$', re.I)
BAND_RE = re.compile(r'(?:^|_)(SR_)?B([1-7])\.TIFF?$', re.I)


def ramp_color(t):
    """0~1 위치의 RdYlGn 색"""
    t = min(1.0, max(0.0, t)) * (len(RAMP) - 1)
    k = min(int(t), len(RAMP) - 2)
    f = t - k
    return tuple(round(RAMP[k][c] + (RAMP[k + 1][c] - RAMP[k][c]) * f) for c in range(3))


def dir_sym(d):
    return '≥' if d == 'ge' else '≤'


# ─────────────────────── 1단계: 폴더에서 장면 찾기 ───────────────────────
class Scene:
    def __init__(self, sid):
        self.id = sid
        self.bands = {}      # 밴드 번호 → GDAL 경로 (.tar 안이면 /vsitar/)
        self.qa = None
        self.mtl = None
        self.sr = False
        self.sensor = ''
        self.level = ''
        self.date = ''
        self.pathrow = ''

    def describe(self):
        bands = ' '.join('B%d' % n for n in sorted(self.bands))
        return '%s · %s · %s · 밴드 %s' % (self.sensor, self.level, self.date or self.id, bands)


def _list_files(folder):
    """(파일명, GDAL 경로, 상위 폴더명) 목록. USGS .tar 는 풀지 않고 /vsitar/ 로 읽는다."""
    out = []
    for root, _dirs, files in os.walk(folder):
        for fn in files:
            full = os.path.join(root, fn)
            if fn.lower().endswith('.tar'):
                try:
                    with tarfile.open(full) as t:
                        for m in t.getmembers():
                            if m.isfile():
                                vsi = '/vsitar/' + full.replace('\\', '/') + '/' + m.name
                                out.append((os.path.basename(m.name), vsi, fn))
                except (tarfile.TarError, OSError):
                    pass
            else:
                out.append((fn, full, os.path.basename(root)))
    return out


def scan_folder(folder):
    scenes = {}
    for name, path, parent in _list_files(folder):
        m = PRODUCT_RE.match(name)
        sid = m.group(1).upper() if m else parent
        suffix = m.group(2) if m else name
        sc = scenes.setdefault(sid, Scene(sid))
        bm = BAND_RE.search(suffix)
        if bm:
            sc.bands[int(bm.group(2))] = path
            if bm.group(1):
                sc.sr = True
        elif re.search(r'QA_PIXEL\.TIFF?$', suffix, re.I):
            sc.qa = path
        elif re.search(r'MTL\.txt$', suffix, re.I):
            sc.mtl = path

    for sid in list(scenes):
        sc = scenes[sid]
        if not sc.bands:
            del scenes[sid]
            continue
        p = sid.split('_')
        if len(p) >= 7:
            sc.sensor = {'LC08': 'Landsat 8', 'LC09': 'Landsat 9'}.get(p[0], p[0])
            sc.level = p[1]
            sc.pathrow = '%s/%s' % (p[2][:3], p[2][3:])
            sc.date = '%s-%s-%s' % (p[3][:4], p[3][4:6], p[3][6:])
            if sc.level.startswith('L2'):
                sc.sr = True
        else:
            sc.sensor = 'Landsat (파일명 미확인)'
            sc.level = 'L2' if sc.sr else '—'
    return scenes


def _read_text(path):
    st = gdal.VSIStatL(path)
    f = gdal.VSIFOpenL(path, 'rb')
    try:
        return gdal.VSIFReadL(1, st.size, f).decode('utf-8', 'replace')
    finally:
        gdal.VSIFCloseL(f)


def parse_mtl(path):
    out = {}
    for kind, band, val in re.findall(r'REFLECTANCE_(MULT|ADD)_BAND_(\d+)\s*=\s*([-+\d.Ee]+)', _read_text(path)):
        out.setdefault(int(band), {})[kind.lower()] = float(val)
    return out


# ─────────────────────── 3단계: 밴드 읽기 ───────────────────────
class Grid:
    """분석 격자 (원본 UTM 좌표계, 해상도만 축소)"""

    def __init__(self, W, H, gt, wkt):
        self.W, self.H, self.gt, self.wkt = W, H, gt, wkt
        self.pixA = abs(gt[1] * gt[5])
        srs = osr.SpatialReference(wkt=wkt)
        srs.AutoIdentifyEPSG()
        self.epsg = srs.GetAuthorityCode(None) or '?'
        self.bands = {}      # n → (dn uint16 배열, mult, add)
        self.qa = None
        self.scale_unit = ''


def open_grid(scene, first_band, target_res):
    ds = gdal.Open(scene.bands[first_band])
    w, h = ds.RasterXSize, ds.RasterYSize
    gt = ds.GetGeoTransform()
    f = max(1.0, target_res / abs(gt[1]))
    W, H = max(1, round(w / f)), max(1, round(h / f))
    g = Grid(W, H, (gt[0], gt[1] * w / W, 0.0, gt[3], 0.0, gt[5] * h / H), ds.GetProjection())
    g.src_size = (w, h)
    return g


def read_band(path, grid):
    ds = gdal.Open(path)
    if (ds.RasterXSize, ds.RasterYSize) != grid.src_size:
        raise ValueError('%s: 영상 크기가 다른 밴드와 다릅니다.' % os.path.basename(path))
    return ds.GetRasterBand(1).ReadAsArray(buf_xsize=grid.W, buf_ysize=grid.H,
                                           resample_alg=gdal.GRIORA_NearestNeighbour)


def band_scale(scene, bands):
    """밴드별 반사율 환산 계수와 단위 설명"""
    if scene.sr:
        return {b: L2_SCALE for b in bands}, '지표면 반사율 (L2 SR)'
    if scene.mtl:
        mtl = parse_mtl(scene.mtl)
        return ({b: (mtl[b]['mult'], mtl[b].get('add', 0.0)) if b in mtl and 'mult' in mtl[b] else (1.0, 0.0)
                 for b in bands}, '대기상단 반사율 (L1 TOA, MTL)')
    return {b: (1.0, 0.0) for b in bands}, 'DN 원시값 (MTL 없음)'


# ─────────────────────── 4단계: 지수 계산 ───────────────────────
class Result:
    def __init__(self, key, data, hist, valid, mean, vmin, vmax):
        self.key = key
        self.data = data          # float32 (H, W), 구름·결측은 NaN
        self.hist = hist
        self.valid = valid
        self.mean = mean
        self.vmin, self.vmax = vmin, vmax
        self.thr = INDICES[key]['thr']
        self.dir = 'ge'
        self.confirmed = None     # (thr, dir)
        self.path = None
        self.layer_id = None

    def is_class_view(self):
        return self.confirmed is not None and self.confirmed == (self.thr, self.dir)

    def passes(self, v, thr=None, d=None):
        thr = self.thr if thr is None else thr
        d = self.dir if d is None else d
        return v >= thr if d == 'ge' else v <= thr

    def class_count(self):
        with np.errstate(invalid='ignore'):
            return int(np.count_nonzero(self.passes(self.data)))


def compute_index(key, grid):
    a_no, b_no = INDICES[key]['bands']
    da, ma, aa = grid.bands[a_no]
    db, mb, ab = grid.bands[b_no]
    a = da.astype(np.float32) * np.float32(ma) + np.float32(aa)
    b = db.astype(np.float32) * np.float32(mb) + np.float32(ab)
    bad = (da == 0) | (db == 0)
    if grid.qa is not None:
        bad |= (grid.qa & QA_MASK) != 0
    with np.errstate(divide='ignore', invalid='ignore'):
        v = 1.5 * (a - b) / (a + b + 0.5) if key == 'SAVI' else (a - b) / (a + b)
    bad |= ~np.isfinite(v)
    v = np.clip(v, -1, 1).astype(np.float32)
    v[bad] = np.nan

    good = v[~bad]
    valid = int(good.size)
    h = np.minimum(((good + 1) * 0.5 * HIST_BINS).astype(np.int32), HIST_BINS - 1)
    hist = np.bincount(h, minlength=HIST_BINS)
    cum = np.cumsum(hist)

    def pct(p):
        i = int(np.searchsorted(cum, p * valid)) if valid else HIST_BINS
        return -1 + (i + 0.5) * 2 / HIST_BINS if i < HIST_BINS else 1.0

    vmin, vmax = pct(0.02), pct(0.98)
    if vmax - vmin < 0.1:
        m = (vmin + vmax) / 2
        vmin, vmax = m - 0.05, m + 0.05
    mean = float(good.mean()) if valid else float('nan')
    return Result(key, v, hist, valid, mean, vmin, vmax)


def write_geotiff(path, grid, data):
    drv = gdal.GetDriverByName('GTiff')
    ds = drv.Create(path, grid.W, grid.H, 1, gdal.GDT_Float32, ['COMPRESS=DEFLATE', 'TILED=YES'])
    ds.SetGeoTransform(grid.gt)
    ds.SetProjection(grid.wkt)
    band = ds.GetRasterBand(1)
    band.SetNoDataValue(float('nan'))
    band.WriteArray(data)
    band.FlushCache()
    ds = None


# ─────────────────────── 6단계: 영역 통계 ───────────────────────
def _vector_driver():
    return ogr.GetDriverByName('Memory') or ogr.GetDriverByName('MEM')


def zonal(grid, geom_wkb, result):
    """
    격자 좌표계(UTM)로 바꾼 폴리곤 WKB 안의 픽셀 통계.
    픽셀 중심이 폴리곤 안에 있으면 포함 (웹 버전 scanline 과 같은 기준).
    반환: dict(area=평면 면적 m², inside, valid, pass_, sum)
    """
    geom = ogr.CreateGeometryFromWkb(bytes(geom_wkb))
    out = dict(area=geom.GetArea(), inside=0, valid=0, pass_=0, sum=0.0)
    gt = grid.gt
    minx, maxx, miny, maxy = geom.GetEnvelope()
    c0 = max(0, int(math.floor((minx - gt[0]) / gt[1])))
    c1 = min(grid.W, int(math.ceil((maxx - gt[0]) / gt[1])))
    r0 = max(0, int(math.floor((maxy - gt[3]) / gt[5])))
    r1 = min(grid.H, int(math.ceil((miny - gt[3]) / gt[5])))
    if c1 <= c0 or r1 <= r0:
        return out

    mem = gdal.GetDriverByName('MEM').Create('', c1 - c0, r1 - r0, 1, gdal.GDT_Byte)
    mem.SetGeoTransform((gt[0] + c0 * gt[1], gt[1], 0.0, gt[3] + r0 * gt[5], 0.0, gt[5]))
    mem.SetProjection(grid.wkt)
    srs = osr.SpatialReference(wkt=grid.wkt)
    vds = _vector_driver().CreateDataSource('zone')
    lyr = vds.CreateLayer('zone', srs, ogr.wkbUnknown)
    feat = ogr.Feature(lyr.GetLayerDefn())
    feat.SetGeometry(geom)
    lyr.CreateFeature(feat)
    gdal.RasterizeLayer(mem, [1], lyr, burn_values=[1])
    mask = mem.GetRasterBand(1).ReadAsArray().astype(bool)

    out['inside'] = int(mask.sum())
    if result is not None:
        vals = result.data[r0:r1, c0:c1][mask]
        vals = vals[~np.isnan(vals)]
        out['valid'] = int(vals.size)
        out['sum'] = float(vals.sum())
        if result.confirmed is not None:
            thr, d = result.confirmed
            out['pass_'] = int(np.count_nonzero(vals >= thr if d == 'ge' else vals <= thr))
    return out
