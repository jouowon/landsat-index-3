# -*- coding: utf-8 -*-
"""QGIS 플러그인 진입점: 도구 모음 버튼 · 메뉴 · 패널(도킹 위젯)"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

MENU = 'Landsat 지수 분석'


class LandsatIndexPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dock = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))
        self.action = QAction(icon, 'Landsat 다중분광지수 분석', self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.triggered.connect(self.toggle)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu(MENU, self.action)

    def unload(self):
        if self.dock is not None:
            self.dock.cleanup()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        self.iface.removePluginRasterMenu(MENU, self.action)
        self.iface.removeToolBarIcon(self.action)

    def toggle(self, checked):
        if self.dock is None:
            from .dock import AnalyzerDock
            self.dock = AnalyzerDock(self.iface)
            self.dock.setObjectName('LandsatIndexAnalyzerDock')
            self.dock.visibilityChanged.connect(self.action.setChecked)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock.setVisible(checked)
        if checked:
            self.dock.raise_()
